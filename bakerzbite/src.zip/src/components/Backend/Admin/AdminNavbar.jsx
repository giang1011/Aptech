import React from 'react';
import { NavLink } from 'react-router-dom';

const AdminNavbar = () => {
  return (
    <nav className="bg-gray-800 h-screen p-4 fixed top-0 left-0">
      <ul className="space-y-4">
        <li>
          <NavLink to="/admin/dashboard" className="text-white block">Dashboard</NavLink>
        </li>
        <li>
          <NavLink to="/admin/categories" className="text-white block">Categories</NavLink>
        </li>
        <li>
          <NavLink to="/admin/products" className="text-white block">Products</NavLink>
        </li>
        <li>
          <NavLink to="/admin/orders" className="text-white block">Orders</NavLink>
        </li>
        <li>
          <NavLink to="/admin/customers" className="text-white block">Customers</NavLink>
        </li>
        <li>
          <NavLink to="/admin/users" className="text-white block">Users</NavLink>
        </li>
      </ul>
    </nav>
  );
};

export default AdminNavbar;
