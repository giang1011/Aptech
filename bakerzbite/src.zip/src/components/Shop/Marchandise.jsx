import React from 'react'

const Marchandise = () => {
  return (
    <div>
      hi
    </div>
  )
}

export default Marchandise
